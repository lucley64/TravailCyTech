<!DOCTYPE html>
<html lang="fr" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta name="description" content="rien"/>
    <meta name="keywords" content="rien"/>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Accueil</title>
    <link rel="stylesheet" href="css/accueilStyle.css">
</head>
<body>
    <h1>"En science, la bonne question ça n'est pas pouquoi mais POURQUOI PAS!"</h1>
    <p>"Oui la science est souvent dangeureuse, et alors?"</p>
    <p>"Si vous avez si peur de vous mouiller, prenez vos clics, vos clacs et retourez au jardin d'enfants, en tout cas vous êtes virés"</p>
</body>
</html>
