# TP -  Variables et Fonctions - Exercice3 - Problème d’appel de fonction

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall toto.c -o toto`

## Execution

Après avoir compilé, executer `./toto`

## Generation de la documentation

Executer `doxygen Doxyfile`
