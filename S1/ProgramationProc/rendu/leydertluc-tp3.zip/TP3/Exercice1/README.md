# TP -  Variables et Fonctions - Exercice1 - Saisie d’entier

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall saisie.c -o saisie`

## Execution

Après avoir compilé, executer `./saisie`

## Generation de la documentation

Executer `doxygen Doxyfile`
