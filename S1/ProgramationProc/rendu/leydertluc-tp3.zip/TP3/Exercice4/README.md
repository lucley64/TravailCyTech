# TP -  Variables et Fonctions - Exercice4 - Programme un peu plus grand

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall menuUtils.c -o menuUtils`

## Execution

Après avoir compilé, executer `./menuUtils`

## Generation de la documentation

Executer `doxygen Doxyfile`
