# TP -  Variables et Fonctions - Exercice2 - Portée d’une variable

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall saisie.c -o saisie`

## Execution

Après avoir compilé, executer `./saisie`

## Generation de la documentation

Executer `doxygen Doxyfile`
