# TP - Entrées, Sorties - Exercice7 - Prédiction

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall prediction.c -o prediction`

## Execution

Après avoir compilé, executer `./prediction`

## Generation de la documentation

Executer `doxygen Doxyfile`
