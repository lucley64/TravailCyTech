# TP - Entrées, Sorties - Exercice4 - Saisie d’une personne

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall saisiePersonne.c -o saisiePersonne`

## Execution

Après avoir compilé, executer `./saisiePersonne`

## Generation de la documentation

Executer `doxygen Doxyfile`
