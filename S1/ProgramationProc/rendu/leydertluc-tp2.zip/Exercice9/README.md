# TP - Entrées, Sorties - Exercice9 - Autre compte à rebours

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall rebours.c -o rebours`

## Execution

Après avoir compilé, executer `./rebours`

## Generation de la documentation

Executer `doxygen Doxyfile`
