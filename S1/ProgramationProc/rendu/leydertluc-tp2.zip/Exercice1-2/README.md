# TP - Entrées, Sorties - Exercice1-2 - Saisie d’un nombre

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall saisieNombre.c -o saisieNombre`

## Execution

Après avoir compilé, executer `./saisieNombre`

## Generation de la documentation

Executer `doxygen Doxyfile`
