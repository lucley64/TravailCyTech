# TP - Entrées, Sorties - Exercice3 - Saisie de deux entiers

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall saisieEntiers.c -o saisieEntiers`

## Execution

Après avoir compilé, executer `./saisieEntiers`

## Generation de la documentation

Executer `doxygen Doxyfile`
