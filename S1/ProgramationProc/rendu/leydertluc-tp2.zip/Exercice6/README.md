# TP - Entrées, Sorties - Exercice1 - Saisie d’un nombre

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall produitNombre.c -o produitNombre`

## Execution

Après avoir compilé, executer `./produitNombre`

## Generation de la documentation

Executer `doxygen Doxyfile`
