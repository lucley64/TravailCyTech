# TP - Entrées, Sorties - Exercice5 - Division d’entier

Deuxième TP correspondant au premier contact avec les entrées / sorties

## Compilation

Executer la commande `gcc -Wall divisionEntiers.c -o divisionEntiers`

## Execution

Après avoir compilé, executer `./divisionEntiers`

## Generation de la documentation

Executer `doxygen Doxyfile`
