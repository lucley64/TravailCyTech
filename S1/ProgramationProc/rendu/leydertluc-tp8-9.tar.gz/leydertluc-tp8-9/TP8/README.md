# TP 6 - 7 -   Tableau et pointeurs

Utiliser le principe de la compilation separée

## Compilation

Executer la commande `make`

## Execution

Après avoir compilé, executer `./bin/a.out`

## Generation de la documentation

Executer `doxygen Doxyfile`
