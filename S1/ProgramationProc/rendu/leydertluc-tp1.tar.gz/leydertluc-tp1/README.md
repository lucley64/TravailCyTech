# TP - Premier contact

Premier tp correspondant aux premier programme de la programmation c

## Compilation

Executer la commande `gcc -Wall hello.c -o hello`

## Execution

Après avoir compilé, executer `./hello`

## Generation de la documentation

Executer `doxygen Doxyfile`
