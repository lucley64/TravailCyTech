Plus grands succés du box-office français entre 1945 et 2015

50 observations
8 variables 
  - 2 nominales
  - 6 numeriques

Nom             Echelle
Genre		Comedie, Aventure, Animation, Action, Drame
Nationalite     FR, GB, US, NZ, IT
Entrees         entre 7 380 526  et  21 773 383
Cout            entre 500 000    et  245 000 000
Recette         entre 2 000 000   et   2 731 068 853
Duree           entre 70 et 238
Prix            entre 0 et 208
Annee           entre 1945 et 2015


